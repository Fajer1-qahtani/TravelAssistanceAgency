
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.travelassistance;
import java.sql.*;
import java.util.Scanner;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
/**
 *
 * @author hp
 */
    public class TravelAssistance {

 
    public static void main(String[] args) throws Exception 
    {
          LoginFrame lf = new LoginFrame();
           lf.setVisible(true);
           
           //Accessing driver from JAR file
          Class.forName("com.mysql.cj.jdbc.Driver");
         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/TravelAssistance?zeroDateTimeBehavior=CONVERT_TO_NULL","root","itsfofo");
            
           PreparedStatement statement = con.prepareStatement("select* from UserInfo");
           
           ResultSet result = statement.executeQuery();
           while(result.next())
           {
               System.out.print(result.getString(1) + " " + result.getString(2));
           }
           
           
         
    }     
}  
 
 
 
  