/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.travelassistance;

import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

/**
 *
 * @author hp
 */
public class France extends javax.swing.JFrame {

    /**
     * Creates new form France
     */
    public France() {
        initComponents();
        scaleImage();
        scaleImage2();
    }

    public void scaleImage(){
        ImageIcon icon = new ImageIcon("C:\\Users\\hp\\Desktop\\Images\\paris.jpg");
        Image img = icon.getImage();
        Image imgScale = img.getScaledInstance(Label.getWidth(), Label.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(imgScale);
        Label.setIcon(scaledIcon);
    }
    public void scaleImage2(){
        ImageIcon icon = new ImageIcon("C:\\Users\\hp\\Desktop\\Images\\tower.jpg");
        Image img = icon.getImage();
        Image imgScale = img.getScaledInstance(Label2.getWidth(), Label2.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(imgScale);
        Label2.setIcon(scaledIcon);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        label = new javax.swing.JLabel();
        Label = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextArea4 = new javax.swing.JTextArea();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        Label2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        hotelTable = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        hotelTable1 = new javax.swing.JTable();
        Close = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(32, 9, 61));
        jPanel1.setPreferredSize(new java.awt.Dimension(781, 563));
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Vivaldi", 3, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("France");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(110, 10, 140, 60);

        jLabel2.setFont(new java.awt.Font("Vivaldi", 3, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("française");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(190, 40, 70, 45);

        jTabbedPane2.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(118, 11, 6));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(null);

        label.setFont(new java.awt.Font("Vivaldi", 3, 48)); // NOI18N
        label.setForeground(new java.awt.Color(255, 255, 255));
        label.setText("Paris");
        jPanel2.add(label);
        label.setBounds(40, 40, 130, 40);

        Label.setText("jLabel2");
        jPanel2.add(Label);
        Label.setBounds(420, 80, 230, 190);

        jScrollPane4.setBackground(new java.awt.Color(0, 51, 51));
        jScrollPane4.setBorder(null);
        jScrollPane4.setForeground(new java.awt.Color(0, 51, 51));

        jTextArea4.setBackground(new java.awt.Color(118, 11, 6));
        jTextArea4.setColumns(20);
        jTextArea4.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        jTextArea4.setForeground(new java.awt.Color(255, 255, 255));
        jTextArea4.setLineWrap(true);
        jTextArea4.setRows(5);
        jTextArea4.setText("the capital and most populous city of France it is known of\nbeing historically rich for example Paris Has One Of The Most\nFamous Paintings In The World the Monalisa by Leonardo da Vinci.\nOne of the nicknames for Paris is the city of light! because it was \none of the first European cities to install street lights.");
        jTextArea4.setAutoscrolls(false);
        jTextArea4.setBorder(null);
        jTextArea4.setDisabledTextColor(new java.awt.Color(0, 51, 51));
        jTextArea4.setSelectedTextColor(new java.awt.Color(0, 51, 51));
        jScrollPane4.setViewportView(jTextArea4);

        jPanel2.add(jScrollPane4);
        jScrollPane4.setBounds(10, 130, 410, 120);

        jTabbedPane2.addTab("City", jPanel2);

        jPanel3.setBackground(new java.awt.Color(118, 11, 6));
        jPanel3.setLayout(null);

        jLabel3.setFont(new java.awt.Font("Vivaldi", 3, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Eiffel Tower");
        jPanel3.add(jLabel3);
        jLabel3.setBounds(10, 50, 240, 30);

        Label2.setText("jLabel3");
        jPanel3.add(Label2);
        Label2.setBounds(430, 0, 240, 350);

        jScrollPane3.setBackground(new java.awt.Color(0, 51, 51));
        jScrollPane3.setBorder(null);
        jScrollPane3.setForeground(new java.awt.Color(0, 51, 51));

        jTextArea3.setBackground(new java.awt.Color(118, 11, 6));
        jTextArea3.setColumns(20);
        jTextArea3.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jTextArea3.setForeground(new java.awt.Color(255, 255, 255));
        jTextArea3.setLineWrap(true);
        jTextArea3.setRows(5);
        jTextArea3.setText("It has since come to represent the distinct character of the city of Paris. Its lights are also often turned on or off to reflect commemoration of major world events. The Eiffel Tower is made almost entirely of open-lattice wrought iron. ");
        jTextArea3.setAutoscrolls(false);
        jTextArea3.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jTextArea3.setDisabledTextColor(new java.awt.Color(0, 51, 51));
        jTextArea3.setSelectedTextColor(new java.awt.Color(0, 51, 51));
        jScrollPane3.setViewportView(jTextArea3);

        jPanel3.add(jScrollPane3);
        jScrollPane3.setBounds(10, 110, 420, 160);

        jTabbedPane2.addTab("LandMark", jPanel3);

        jPanel4.setBackground(new java.awt.Color(118, 11, 6));

        hotelTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"Paris Marriott Champs Elysees  Hotel  ", "4599"},
                {"Hotel Napoleon ", "7800"},
                {"Pullman Paris Montparnasse", "3459"}
            },
            new String [] {
                "Hotel names", "Prices"
            }
        ));
        hotelTable.setColumnSelectionAllowed(true);
        jScrollPane1.setViewportView(hotelTable);
        hotelTable.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 523, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(96, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(208, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Hotels", jPanel4);

        jPanel5.setBackground(new java.awt.Color(118, 11, 6));

        hotelTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"Qatari Airlines", "3000 "},
                {"Emarati Airlines", "3500"},
                {"Saudia  Airlines", "7557"}
            },
            new String [] {
                "Company name ", "Price of ticket "
            }
        ));
        jScrollPane2.setViewportView(hotelTable1);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 523, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(109, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(207, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("FlightTickets", jPanel5);

        jPanel1.add(jTabbedPane2);
        jTabbedPane2.setBounds(30, 90, 670, 380);

        Close.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Close.setForeground(new java.awt.Color(255, 255, 255));
        Close.setText("X");
        Close.setBorderPainted(false);
        Close.setContentAreaFilled(false);
        Close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CloseMouseClicked(evt);
            }
        });
        Close.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CloseActionPerformed(evt);
            }
        });
        jPanel1.add(Close);
        Close.setBounds(760, 10, 80, 30);

        jButton1.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("<");
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(10, 10, 80, 40);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 864, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void CloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CloseMouseClicked
        this.setState(JFrame.ICONIFIED);
        System.exit(0);
    }//GEN-LAST:event_CloseMouseClicked

    private void CloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CloseActionPerformed
        this.setState(JFrame.ICONIFIED);
        System.exit(0);
    }//GEN-LAST:event_CloseActionPerformed

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        Assistance a = new Assistance();
        a.setVisible(true);
        a.pack();
        a.setLocationRelativeTo(null);
        a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_jButton1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(France.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(France.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(France.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(France.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new France().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Close;
    private javax.swing.JLabel Label;
    private javax.swing.JLabel Label2;
    private javax.swing.JTable hotelTable;
    private javax.swing.JTable hotelTable1;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JTextArea jTextArea4;
    private javax.swing.JLabel label;
    // End of variables declaration//GEN-END:variables
}
