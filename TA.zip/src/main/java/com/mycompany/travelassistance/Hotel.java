/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.travelassistance;

/**
 *
 * @author hp
 */
public class Hotel {
    private String hotel_name;
   private double hotel_price;         

    public String getHotel_name() {
        return hotel_name;
    }

    public void setHotel_name(String hotel_name) {
        this.hotel_name = hotel_name;
    }

    public double getHotel_price() {
        return hotel_price;
    }

    public void setHotel_price(double hotel_price) {
        this.hotel_price = hotel_price;
    }

    public Hotel(String hotel_name, double hotel_price) {
        this.hotel_name = hotel_name;
        this.hotel_price = hotel_price;
    }
}
