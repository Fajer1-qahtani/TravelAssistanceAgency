/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.travelassistance;

import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author hp
 */
public class USA extends javax.swing.JFrame {

   
    public USA() {
        initComponents();
        scaleImage();
        scaleImage2();
        scaleImage3();
        show_hotel();
    }
  public void scaleImage(){
        ImageIcon icon = new ImageIcon("C:\\Users\\hp\\Desktop\\Images\\nyc.jpg");
        Image img = icon.getImage();
        Image imgScale = img.getScaledInstance(Label.getWidth(), Label.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(imgScale);
        Label.setIcon(scaledIcon);
    }
     public void scaleImage2(){
        ImageIcon icon = new ImageIcon("C:\\Users\\hp\\Desktop\\Images\\SoL.jpg");
        Image img = icon.getImage();
        Image imgScale = img.getScaledInstance(Label2.getWidth(), Label2.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(imgScale);
        Label2.setIcon(scaledIcon);
    }
      public void scaleImage3(){
        ImageIcon icon = new ImageIcon("C:\\Users\\hp\\Desktop\\Images\\Bartholdi.jpg");
        Image img = icon.getImage();
        Image imgScale = img.getScaledInstance(Label3.getWidth(), Label3.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(imgScale);
        Label3.setIcon(scaledIcon);
    }
   
    public ArrayList<Hotel> hotelList(){
        ArrayList<Hotel> hotelList = new ArrayList<>();
        try{
     Class.forName("com.mysql.cj.jdbc.Driver");
     Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/TravelAssistance?zeroDateTimeBehavior=CONVERT_TO_NULL","root","itsfofo");
     PreparedStatement st = con.prepareStatement("SELECT * FROM Hotel WHERE city = New York");
    ResultSet rs = st.executeQuery();
    Hotel hotel;
    while(rs.next()){
        hotel = new Hotel (rs.getString("hotel_name"),rs.getDouble("hotel_price"));
        hotelList.add(hotel);
    }
    }
    
        catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(LoginFrame.class.getName()).log(Level.SEVERE, null, ex);
    } 
        return hotelList;
    }     
    public void show_hotel(){
        ArrayList<Hotel> list = hotelList();
        DefaultTableModel model = (DefaultTableModel)hotelTable.getModel();
        Object[] row = new Object[2];
        for(int i = 0; i<list.size(); i++){
         row[0] = list.get(i).getHotel_name();
         row[1] = list.get(i).getHotel_price();
         model.addRow(row);
        }
    }
  
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        city = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        city1 = new javax.swing.JLabel();
        Label = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextArea4 = new javax.swing.JTextArea();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        Label2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        Label3 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        hotelTable = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        hotelTable1 = new javax.swing.JTable();
        Close = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(60, 128, 173));
        jPanel1.setLayout(null);

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("United States of America");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(100, 30, 520, 40);

        city.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        city.setText("City : New York");
        jPanel1.add(city);
        city.setBounds(130, 70, 190, 40);

        jButton1.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("<");
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(0, 10, 80, 40);

        jTabbedPane2.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(172, 41, 41));
        jPanel2.setLayout(null);

        city1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        city1.setForeground(new java.awt.Color(255, 255, 255));
        city1.setText(" New York City ");
        jPanel2.add(city1);
        city1.setBounds(230, 20, 220, 40);

        Label.setText("jLabel2");
        jPanel2.add(Label);
        Label.setBounds(440, 80, 230, 190);

        jScrollPane4.setBackground(new java.awt.Color(0, 51, 51));
        jScrollPane4.setBorder(null);
        jScrollPane4.setForeground(new java.awt.Color(0, 51, 51));

        jTextArea4.setBackground(new java.awt.Color(172, 41, 41));
        jTextArea4.setColumns(20);
        jTextArea4.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jTextArea4.setForeground(new java.awt.Color(255, 255, 255));
        jTextArea4.setLineWrap(true);
        jTextArea4.setRows(5);
        jTextArea4.setText("More than 800 languages are spoken in New York City,\nmaking it the most linguistically diverse city in the world.\n4 in 10 households speak a language other than English.\nNew York City became the first capital of the United States in 1789.");
        jTextArea4.setAutoscrolls(false);
        jTextArea4.setBorder(null);
        jTextArea4.setDisabledTextColor(new java.awt.Color(0, 51, 51));
        jTextArea4.setSelectedTextColor(new java.awt.Color(0, 51, 51));
        jScrollPane4.setViewportView(jTextArea4);

        jPanel2.add(jScrollPane4);
        jScrollPane4.setBounds(10, 130, 410, 120);

        jTabbedPane2.addTab("City", jPanel2);

        jPanel3.setBackground(new java.awt.Color(172, 41, 41));
        jPanel3.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Statue of Liberty");
        jPanel3.add(jLabel2);
        jLabel2.setBounds(10, 50, 240, 32);

        Label2.setText("jLabel3");
        jPanel3.add(Label2);
        Label2.setBounds(420, 0, 250, 170);

        jScrollPane3.setBackground(new java.awt.Color(0, 51, 51));
        jScrollPane3.setBorder(null);
        jScrollPane3.setForeground(new java.awt.Color(0, 51, 51));

        jTextArea3.setBackground(new java.awt.Color(172, 41, 41));
        jTextArea3.setColumns(20);
        jTextArea3.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jTextArea3.setForeground(new java.awt.Color(255, 255, 255));
        jTextArea3.setLineWrap(true);
        jTextArea3.setRows(5);
        jTextArea3.setText("is a colossal neoclassical sculpture on Liberty Island in \nNew York, it was a gift from the people of France, was \ndesigned by French sculptor Frédéric Auguste Bartholdi\nThe statue is a figure of Libertas, a robed Roman liberty\ngoddess. She holds a torch above her head with her right \nhand and in her left hand carries a tabula ansata ");
        jTextArea3.setAutoscrolls(false);
        jTextArea3.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jTextArea3.setDisabledTextColor(new java.awt.Color(0, 51, 51));
        jTextArea3.setSelectedTextColor(new java.awt.Color(0, 51, 51));
        jScrollPane3.setViewportView(jTextArea3);

        jPanel3.add(jScrollPane3);
        jScrollPane3.setBounds(10, 110, 390, 160);

        Label3.setText("jLabel3");
        jPanel3.add(Label3);
        Label3.setBounds(420, 170, 250, 180);

        jTabbedPane2.addTab("LandMark", jPanel3);

        jPanel4.setBackground(new java.awt.Color(172, 41, 41));

        hotelTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"The Langham", "3500"},
                {"Waldorf-Astoria ", "6399"},
                {"The Ritz-Carlton", "10000"}
            },
            new String [] {
                "Hotel names", "Prices"
            }
        ));
        hotelTable.setColumnSelectionAllowed(true);
        jScrollPane1.setViewportView(hotelTable);
        hotelTable.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 523, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(96, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(208, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Hotels", jPanel4);

        jPanel5.setBackground(new java.awt.Color(172, 41, 41));

        hotelTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"Qatari Airlines", "2250"},
                {"Emarati Airlines", "4000"},
                {"Saudia  Airlines", "5909"}
            },
            new String [] {
                "Company name ", "Price of ticket "
            }
        ));
        jScrollPane2.setViewportView(hotelTable1);
        hotelTable1.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 523, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(109, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(207, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("FlightTickets", jPanel5);

        jPanel1.add(jTabbedPane2);
        jTabbedPane2.setBounds(30, 120, 670, 380);

        Close.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Close.setForeground(new java.awt.Color(255, 255, 255));
        Close.setText("X");
        Close.setBorderPainted(false);
        Close.setContentAreaFilled(false);
        Close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CloseMouseClicked(evt);
            }
        });
        jPanel1.add(Close);
        Close.setBounds(693, 20, 60, 23);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 781, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 563, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void CloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CloseMouseClicked
        this.setState(JFrame.ICONIFIED);
        System.exit(0);
    }//GEN-LAST:event_CloseMouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        Assistance a = new Assistance();
        a.setVisible(true);
        a.pack();
        a.setLocationRelativeTo(null);
        a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_jButton1MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new USA().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Close;
    private javax.swing.JLabel Label;
    private javax.swing.JLabel Label2;
    private javax.swing.JLabel Label3;
    private javax.swing.JLabel city;
    private javax.swing.JLabel city1;
    private javax.swing.JTable hotelTable;
    private javax.swing.JTable hotelTable1;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JTextArea jTextArea4;
    // End of variables declaration//GEN-END:variables
}
